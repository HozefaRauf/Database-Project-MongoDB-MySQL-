public class PharmacyFunction {
    public static String billpath = "D:\\Bills";
}
